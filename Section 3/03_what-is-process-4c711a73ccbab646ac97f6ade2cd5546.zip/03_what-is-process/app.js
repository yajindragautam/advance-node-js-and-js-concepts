const a = process;
console.log(a);
// while (true) {}

// setInterval(() => {
//   console.log("hello");
// }, 100);
